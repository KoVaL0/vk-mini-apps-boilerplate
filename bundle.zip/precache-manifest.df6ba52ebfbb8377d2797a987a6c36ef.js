self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "21831e931267ea8beea0fbe9d2b54200",
    "url": "/index.html"
  },
  {
    "revision": "12e878af526e0778490b",
    "url": "/static/css/2.b84722ed.chunk.css"
  },
  {
    "revision": "29a75d6b67c63f2f79db",
    "url": "/static/css/main.cff8d464.chunk.css"
  },
  {
    "revision": "12e878af526e0778490b",
    "url": "/static/js/2.2fe4c09c.chunk.js"
  },
  {
    "revision": "87f1c48a6b299dccc37ab9301d949db7",
    "url": "/static/js/2.2fe4c09c.chunk.js.LICENSE.txt"
  },
  {
    "revision": "29a75d6b67c63f2f79db",
    "url": "/static/js/main.40439db0.chunk.js"
  },
  {
    "revision": "1d69de3534f34e85c652",
    "url": "/static/js/runtime-main.56bd2bf8.js"
  },
  {
    "revision": "432707c7863ede29b9a7cfd99b6cad20",
    "url": "/static/media/hi.432707c7.png"
  },
  {
    "revision": "05d9e04041849d0144f6b16d1e1a3ad5",
    "url": "/static/media/logo.05d9e040.png"
  },
  {
    "revision": "772b6b721df1d2357dd7e8c126d05508",
    "url": "/static/media/money-bag.772b6b72.png"
  }
]);