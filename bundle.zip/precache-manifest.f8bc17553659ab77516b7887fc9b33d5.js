self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "25b6e74b6d01b371121b46287ec7a835",
    "url": "/index.html"
  },
  {
    "revision": "8745fe4327d04b3ecde4",
    "url": "/static/css/2.b2ab281c.chunk.css"
  },
  {
    "revision": "c1540b63094809367870",
    "url": "/static/css/main.526954ca.chunk.css"
  },
  {
    "revision": "8745fe4327d04b3ecde4",
    "url": "/static/js/2.ff7e25a0.chunk.js"
  },
  {
    "revision": "87f1c48a6b299dccc37ab9301d949db7",
    "url": "/static/js/2.ff7e25a0.chunk.js.LICENSE.txt"
  },
  {
    "revision": "c1540b63094809367870",
    "url": "/static/js/main.b7d50038.chunk.js"
  },
  {
    "revision": "1d69de3534f34e85c652",
    "url": "/static/js/runtime-main.56bd2bf8.js"
  },
  {
    "revision": "432707c7863ede29b9a7cfd99b6cad20",
    "url": "/static/media/hi.432707c7.png"
  },
  {
    "revision": "05d9e04041849d0144f6b16d1e1a3ad5",
    "url": "/static/media/logo.05d9e040.png"
  },
  {
    "revision": "772b6b721df1d2357dd7e8c126d05508",
    "url": "/static/media/money-bag.772b6b72.png"
  }
]);